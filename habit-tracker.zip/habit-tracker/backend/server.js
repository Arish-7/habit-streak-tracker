const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/habit-tracker', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log('Connected to MongoDB');
}).catch(err => {
  console.log('MongoDB connection error:', err);
});

// Simple Habit Schema
const habitSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  description: String,
  currentStreak: {
    type: Number,
    default: 0
  },
  bestStreak: {
    type: Number,
    default: 0
  },
  lastCompleted: Date,
  completedDates: [{
    date: Date,
    completed: Boolean
  }],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const Habit = mongoose.model('Habit', habitSchema);

// Badge Schema
const badgeSchema = new mongoose.Schema({
  name: String,
  description: String,
  unlocked: {
    type: Boolean,
    default: false
  },
  icon: {
    type: String,
    default: '🏆'
  }
});

const Badge = mongoose.model('Badge', badgeSchema);

// Initialize default badges
async function initializeBadges() {
  const badgeCount = await Badge.countDocuments();
  if (badgeCount === 0) {
    const defaultBadges = [
      { name: 'First Step', description: 'Create your first habit', icon: '🚀' },
      { name: 'Week Warrior', description: '7-day streak', icon: '💪' },
      { name: 'Month Master', description: '30-day streak', icon: '🏆' },
      { name: 'Consistency King', description: '3-month streak', icon: '👑' },
      { name: 'Habit Hero', description: 'Complete 5 habits', icon: '🦸' }
    ];
    await Badge.insertMany(defaultBadges);
    console.log('Default badges created');
  }
}

// Routes

// Get all habits
app.get('/api/habits', async (req, res) => {
  try {
    const habits = await Habit.find().sort({ createdAt: -1 });
    res.json(habits);
  } catch (error) {
    console.error('Error fetching habits:', error);
    res.status(500).json({ message: 'Error fetching habits' });
  }
});

// Create new habit
app.post('/api/habits', async (req, res) => {
  try {
    const { name, description } = req.body;
    const habit = new Habit({ name, description });
    await habit.save();
    res.status(201).json(habit);
  } catch (error) {
    console.error('Error creating habit:', error);
    res.status(400).json({ message: 'Error creating habit' });
  }
});

// Complete habit
app.patch('/api/habits/:id/complete', async (req, res) => {
  try {
    const habit = await Habit.findById(req.params.id);
    if (!habit) {
      return res.status(404).json({ message: 'Habit not found' });
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Check if already completed today
    const alreadyCompleted = habit.completedDates.some(entry => {
      const entryDate = new Date(entry.date);
      entryDate.setHours(0, 0, 0, 0);
      return entryDate.getTime() === today.getTime() && entry.completed;
    });

    if (alreadyCompleted) {
      return res.status(400).json({ message: 'Habit already completed today' });
    }

    // Add completion
    habit.completedDates.push({
      date: today,
      completed: true
    });

    // Calculate streak
    const sortedDates = habit.completedDates
      .filter(d => d.completed)
      .map(d => new Date(d.date))
      .sort((a, b) => b - a);

    let currentStreak = 0;
    let tempDate = new Date(today);

    for (let i = 0; i < sortedDates.length; i++) {
      const checkDate = new Date(tempDate);
      checkDate.setHours(0, 0, 0, 0);

      const found = sortedDates.some(d => {
        const compareDate = new Date(d);
        compareDate.setHours(0, 0, 0, 0);
        return compareDate.getTime() === checkDate.getTime();
      });

      if (found) {
        currentStreak++;
        tempDate.setDate(tempDate.getDate() - 1);
      } else {
        break;
      }
    }

    habit.currentStreak = currentStreak;
    habit.bestStreak = Math.max(habit.bestStreak, currentStreak);
    habit.lastCompleted = today;

    await habit.save();
    res.json(habit);
  } catch (error) {
    console.error('Error completing habit:', error);
    res.status(500).json({ message: 'Error completing habit' });
  }
});

// Delete habit
app.delete('/api/habits/:id', async (req, res) => {
  try {
    await Habit.findByIdAndDelete(req.params.id);
    res.json({ message: 'Habit deleted successfully' });
  } catch (error) {
    console.error('Error deleting habit:', error);
    res.status(500).json({ message: 'Error deleting habit' });
  }
});

// Get badges
app.get('/api/badges', async (req, res) => {
  try {
    const badges = await Badge.find();
    res.json(badges);
  } catch (error) {
    console.error('Error fetching badges:', error);
    res.status(500).json({ message: 'Error fetching badges' });
  }
});

// Update badge (unlock)
app.patch('/api/badges/:id', async (req, res) => {
  try {
    const badge = await Badge.findByIdAndUpdate(
      req.params.id,
      { unlocked: req.body.unlocked },
      { new: true }
    );
    res.json(badge);
  } catch (error) {
    console.error('Error updating badge:', error);
    res.status(500).json({ message: 'Error updating badge' });
  }
});

// Get stats
app.get('/api/stats', async (req, res) => {
  try {
    const habits = await Habit.find();
    const stats = {
      activeHabits: habits.length,
      bestStreak: Math.max(...habits.map(h => h.bestStreak), 0),
      currentStreak: Math.max(...habits.map(h => h.currentStreak), 0),
      totalCompletions: habits.reduce((sum, h) => sum + h.completedDates.filter(d => d.completed).length, 0)
    };
    res.json(stats);
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ message: 'Error fetching stats' });
  }
});

// Health check
app.get('/', (req, res) => {
  res.json({ message: 'Habit Tracker API is running!' });
});

const PORT = process.env.PORT || 5000;

// Start server
app.listen(PORT, async () => {
  console.log(`Server running on port ${PORT}`);
  await initializeBadges();
});