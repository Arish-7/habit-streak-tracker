const API_BASE = 'http://localhost:5000/api';

// DOM Elements
const habitsList = document.getElementById('habits-list');
const emptyHabits = document.getElementById('empty-habits');
const addHabitBtn = document.getElementById('add-habit-btn');
const addHabitModal = document.getElementById('add-habit-modal');
const addHabitForm = document.getElementById('add-habit-form');
const cancelHabitBtn = document.getElementById('cancel-habit-btn');
const activeHabitsCount = document.getElementById('active-habits-count');
const bestStreak = document.getElementById('best-streak');
const currentStreak = document.getElementById('current-streak');
const calendarContainer = document.getElementById('calendar-container');
const badgesContainer = document.getElementById('badges-container');

// State
let habits = [];
let badges = [];
let stats = {};

// Initialize app
async function init() {
    await loadHabits();
    await loadBadges();
    await loadStats();
    renderCalendar();
    
    // Event listeners
    addHabitBtn.addEventListener('click', () => {
        addHabitModal.style.display = 'flex';
    });
    
    cancelHabitBtn.addEventListener('click', () => {
        addHabitModal.style.display = 'none';
        addHabitForm.reset();
    });
    
    addHabitForm.addEventListener('submit', handleAddHabit);
}

// API Functions
async function apiCall(endpoint, options = {}) {
    try {
        const response = await fetch(`${API_BASE}${endpoint}`, {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('API call failed:', error);
        return null;
    }
}

async function loadHabits() {
    const data = await apiCall('/habits');
    habits = data || [];
    renderHabits();
}

async function loadBadges() {
    const data = await apiCall('/badges');
    badges = data || [];
    renderBadges();
}

async function loadStats() {
    const data = await apiCall('/stats');
    stats = data || {};
    updateStats();
}

async function createHabit(habitData) {
    const newHabit = await apiCall('/habits', {
        method: 'POST',
        body: JSON.stringify(habitData)
    });
    
    if (newHabit) {
        habits.push(newHabit);
        renderHabits();
        await loadStats();
        await checkAndUnlockBadges();
    }
    return newHabit;
}

async function completeHabit(habitId) {
    const updatedHabit = await apiCall(`/habits/${habitId}/complete`, {
        method: 'PATCH'
    });
    
    if (updatedHabit) {
        habits = habits.map(h => h._id === habitId ? updatedHabit : h);
        renderHabits();
        await loadStats();
        await checkAndUnlockBadges();
    }
    return updatedHabit;
}

async function deleteHabit(habitId) {
    const result = await apiCall(`/habits/${habitId}`, {
        method: 'DELETE'
    });
    
    if (result) {
        habits = habits.filter(h => h._id !== habitId);
        renderHabits();
        await loadStats();
        await checkAndUnlockBadges();
    }
}

async function unlockBadge(badgeId) {
    await apiCall(`/badges/${badgeId}`, {
        method: 'PATCH',
        body: JSON.stringify({ unlocked: true })
    });
}

// Render Functions
function renderHabits() {
    habitsList.innerHTML = '';
    
    if (habits.length === 0) {
        emptyHabits.style.display = 'block';
        return;
    }
    
    emptyHabits.style.display = 'none';
    
    habits.forEach(habit => {
        const habitItem = document.createElement('div');
        habitItem.className = 'habit-item';
        
        const isCompletedToday = () => {
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            return habit.completedDates.some(entry => {
                const entryDate = new Date(entry.date);
                entryDate.setHours(0, 0, 0, 0);
                return entryDate.getTime() === today.getTime() && entry.completed;
            });
        };
        
        habitItem.innerHTML = `
            <div class="habit-info">
                <div class="habit-name">${habit.name}</div>
                <div class="habit-streak">Current streak: ${habit.currentStreak} days | Best streak: ${habit.bestStreak} days</div>
                ${habit.description ? `<div class="habit-description">${habit.description}</div>` : ''}
            </div>
            <div class="habit-actions">
                ${!isCompletedToday() ? `<button class="btn btn-success" data-id="${habit._id}">Complete</button>` : ''}
                <button class="btn btn-danger" data-id="${habit._id}">Delete</button>
            </div>
        `;
        habitsList.appendChild(habitItem);
    });
    
    // Add event listeners
    document.querySelectorAll('.btn-success').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const habitId = e.target.getAttribute('data-id');
            completeHabit(habitId);
        });
    });
    
    document.querySelectorAll('.btn-danger').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const habitId = e.target.getAttribute('data-id');
            if (confirm('Are you sure you want to delete this habit?')) {
                deleteHabit(habitId);
            }
        });
    });
}

function renderBadges() {
    badgesContainer.innerHTML = '';
    
    badges.forEach(badge => {
        const badgeElement = document.createElement('div');
        badgeElement.className = `badge ${badge.unlocked ? 'unlocked' : 'locked'}`;
        badgeElement.innerHTML = `
            <div class="badge-icon">${badge.icon}</div>
            <div class="badge-name">${badge.name}</div>
        `;
        badgeElement.title = badge.description;
        badgesContainer.appendChild(badgeElement);
    });
}

function renderCalendar() {
    calendarContainer.innerHTML = '';
    
    // Generate mock calendar data (84 days = 12 weeks)
    for (let i = 0; i < 84; i++) {
        const day = document.createElement('div');
        const intensity = Math.floor(Math.random() * 5); // 0-4
        day.className = `calendar-day ${intensity === 0 ? 'empty' : intensity === 1 ? 'low' : intensity === 2 ? 'medium' : intensity === 3 ? 'high' : 'max'}`;
        calendarContainer.appendChild(day);
    }
}

function updateStats() {
    activeHabitsCount.textContent = stats.activeHabits || 0;
    bestStreak.textContent = stats.bestStreak || 0;
    currentStreak.textContent = stats.currentStreak || 0;
}

// Event Handlers
async function handleAddHabit(e) {
    e.preventDefault();
    
    const name = document.getElementById('habit-name').value.trim();
    const description = document.getElementById('habit-description').value.trim();
    
    if (!name) {
        alert('Please enter a habit name');
        return;
    }
    
    await createHabit({ name, description });
    
    addHabitModal.style.display = 'none';
    addHabitForm.reset();
}

// Badge Logic
async function checkAndUnlockBadges() {
    // First Step badge
    if (habits.length >= 1 && badges[0] && !badges[0].unlocked) {
        await unlockBadge(badges[0]._id);
        await loadBadges();
    }
    
    // Week Warrior badge
    const hasWeekStreak = habits.some(h => h.currentStreak >= 7);
    if (hasWeekStreak && badges[1] && !badges[1].unlocked) {
        await unlockBadge(badges[1]._id);
        await loadBadges();
    }
    
    // Month Master badge
    const hasMonthStreak = habits.some(h => h.currentStreak >= 30);
    if (hasMonthStreak && badges[2] && !badges[2].unlocked) {
        await unlockBadge(badges[2]._id);
        await loadBadges();
    }
    
    // Habit Hero badge
    if (habits.length >= 5 && badges[4] && !badges[4].unlocked) {
        await unlockBadge(badges[4]._id);
        await loadBadges();
    }
}

// Initialize the app
document.addEventListener('DOMContentLoaded', init);